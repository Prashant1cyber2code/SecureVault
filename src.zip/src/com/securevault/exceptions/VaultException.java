package com.securevault.exceptions;

public class VaultException extends Exception {
    public VaultException(String message) {
        super(message);
    }
}